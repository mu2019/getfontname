#!/usr/bin/env python
# -*- coding: utf-8 -*-


from  .fontname import get_font_name
#.get_font_name as 
from .fontfile import get_font_file
#.get_font_file as get_font_name


